-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2023 at 06:43 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `appointment`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment_tb`
--

CREATE TABLE `appointment_tb` (
  `appointment_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment_tb`
--

INSERT INTO `appointment_tb` (`appointment_id`, `doctor_id`, `user_id`, `date`, `time`) VALUES
(4, 21, 3, '2023-06-22', '22:41:00'),
(5, 25, 4, '2023-06-17', '18:25:00'),
(6, 28, 4, '2023-06-24', '12:22:00'),
(7, 28, 4, '2023-06-23', '13:05:00'),
(8, 21, 5, '2023-06-16', '19:12:00');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_tb`
--

CREATE TABLE `doctor_tb` (
  `d_id` int(11) NOT NULL,
  `d_name` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `experiance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor_tb`
--

INSERT INTO `doctor_tb` (`d_id`, `d_name`, `department`, `experiance`) VALUES
(21, 'eqf', 'qwe', 2),
(25, 'mr.patel', 'heart', 4),
(26, 'mr.A.R.Shah', 'eyes', 7),
(27, 'mr.J.H.Birla', 'heart', 5),
(28, 'R.R.goinka ', 'physician', 10);

-- --------------------------------------------------------

--
-- Table structure for table `user_tb`
--

CREATE TABLE `user_tb` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(10) NOT NULL,
  `phone_no` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_tb`
--

INSERT INTO `user_tb` (`id`, `username`, `password`, `phone_no`) VALUES
(3, 'Admin', '1234', '8888888888'),
(4, 'abc', '123', '123'),
(5, 'cde', '456', '1234'),
(6, 'efg', '789', '1234'),
(7, 'pqr', '147', '1234'),
(8, 'margi', '1703', '8401200162'),
(9, 'margi', '173', '8401200162');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment_tb`
--
ALTER TABLE `appointment_tb`
  ADD PRIMARY KEY (`appointment_id`),
  ADD KEY `fk-doctor_id` (`doctor_id`),
  ADD KEY `fk-user_id` (`user_id`);

--
-- Indexes for table `doctor_tb`
--
ALTER TABLE `doctor_tb`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `user_tb`
--
ALTER TABLE `user_tb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment_tb`
--
ALTER TABLE `appointment_tb`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `doctor_tb`
--
ALTER TABLE `doctor_tb`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `user_tb`
--
ALTER TABLE `user_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment_tb`
--
ALTER TABLE `appointment_tb`
  ADD CONSTRAINT `fk-doctor_id` FOREIGN KEY (`doctor_id`) REFERENCES `doctor_tb` (`d_id`),
  ADD CONSTRAINT `fk-user_id` FOREIGN KEY (`user_id`) REFERENCES `user_tb` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
